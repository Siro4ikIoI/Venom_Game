import http.server
import socketserver
import mimetypes

class GzipHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def guess_type(self, path):
        """Определение типа MIME для корректного Content-Type"""
        mime_type, _ = mimetypes.guess_type(path)
        return mime_type or "application/octet-stream"

    def end_headers(self):
        """Добавление заголовка Content-Encoding для .gz файлов"""
        if self.path.endswith(".gz"):
            self.send_header("Content-Encoding", "gzip")
            self.send_header("Content-Type", self.guess_type(self.path))
        super().end_headers()

PORT = 8000
with socketserver.TCPServer(("", PORT), GzipHTTPRequestHandler) as httpd:
    print(f"Сервер запущен на http://localhost:{PORT}")
    httpd.serve_forever()
